import DispatchForm from './DispatchForm';

function App() {
  return <DispatchForm />;
}

export default App;
